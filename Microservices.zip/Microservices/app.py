# Local imports
import datetime

# Third part imports
from flask import request
import numpy as np
import pandas as pd

# calculate accuracy measures and confusion matrix
from sklearn import metrics
from sklearn.tree import DecisionTreeClassifier
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression

from ms import app
from ms.functions import get_model_response


model_name = "Breast Cancer Wisconsin (Diagnostic)"
model_file = 'model_binary.dat.gz'
version = "v1.0.0"


@app.route('/info', methods=['GET'])
def info():
    """Return model information, version, how to call"""
    result = {}

    result["name"] = model_name
    result["version"] = version

    return result


@app.route('/health', methods=['GET'])
def health():
    """Return service health"""
    return 'ok'


@app.route('/predict', methods=['POST'])
def predict():
    feature_dict = request.get_json()
    if not feature_dict:
        return {
            'error': 'Body is empty.'
        }, 500

    try:
        response = get_model_response(feature_dict)
    except ValueError as e:
        return {'error': str(e).split('\n')[-1].strip()}, 500

    return response, 200

def get_model_response(feature_dict):
    df = pd.read_csv("breast_cancer.csv")
    df = df.drop("id",axis = 1)
    del df[df. columns[-1]]
    df.loc[df['diagnosis'] == 'M', 'diagnosis'] = 1
    df.loc[df['diagnosis'] == 'B', 'diagnosis'] = 0
    X = df.drop("diagnosis", axis = 1)
    y = df.pop("diagnosis")

    model = LogisticRegression()
    model.fit(X, y)
    y_predict = model.predict(feature_dict)
    
    return y_predict

if __name__ == '__main__':
    app.run(host='0.0.0.0')
